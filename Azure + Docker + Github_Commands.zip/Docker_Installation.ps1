﻿Install-Module DockerMsftProvider -Force

Install-Package Docker -ProviderName DockerMsftProvider -Force

(Install-WindowsFeature Containers).RestartNeeded