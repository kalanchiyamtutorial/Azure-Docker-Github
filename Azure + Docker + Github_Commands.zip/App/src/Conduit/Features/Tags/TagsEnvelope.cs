using System.Collections.Generic;

namespace Conduit.Features.Tags
{
    public class TagsEnvelope
    {
        public List<string> Tags { get; set; }
    }
}